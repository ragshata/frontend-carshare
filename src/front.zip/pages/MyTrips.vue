<template><div class="p-6 text-lg">Экран «Мои поездки»</div></template>
<script setup lang="ts"></script>
