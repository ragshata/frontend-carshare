<template>
  <div class="trip-details-page" v-if="trip">
    <button class="btn-back" @click="router.push('/find-trip')">← Назад</button>
    <h2 class="title">{{ trip.from_city }} — {{ trip.to_city }}</h2>

    <div class="details-block">
      <div class="detail-row">
        <span>Дата:</span> <b>{{ trip.date }}</b>
      </div>
      <div class="detail-row">
        <span>Время:</span> <b>{{ trip.time }}</b>
      </div>
      <div class="detail-row">
        <span>Стоимость:</span> <b>{{ trip.price }} ₽</b>
      </div>
      <div class="detail-row">
        <span>Мест:</span> <b>{{ trip.seats }}</b>
      </div>
      <div class="detail-row">
        <span>Статус:</span> <b>{{ trip.status }}</b>
      </div>
      <div class="detail-row">
        <span>Описание:</span>
        <b v-if="trip.description">{{ trip.description }}</b>
        <span v-else>—</span>
      </div>
    </div>

    <button class="btn" @click="handleBookTrip">Забронировать</button>
    <Toast ref="toastRef" />
  </div>
  <div v-else class="loading">
    Загрузка...
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import Toast from '@/components/Toast.vue';
import { getTripById } from '@/api/trips';
import { bookTrip as apiBookTrip } from '@/api/bookings';
import { useAuthStore } from '@/store/auth';

const route = useRoute();
const router = useRouter();
const toastRef = ref<InstanceType<typeof Toast> | null>(null);
const auth = useAuthStore();

const trip = ref<any>(null);

onMounted(async () => {
  try {
    const id = Number(route.params.id);
    if (!id) throw new Error('Нет id поездки');
    trip.value = await getTripById(id);
  } catch (e) {
    toastRef.value?.show('Ошибка загрузки поездки');
    router.push('/find-trip');
  }
});

async function handleBookTrip() {
  if (!trip.value) return;
  try {
    await apiBookTrip(trip.value.id, auth.user.id);
    toastRef.value?.show('🚗 Бронирование успешно!');
  } catch (err) {
    toastRef.value?.show('❌ Ошибка бронирования');
  }
}
</script>

<style scoped>
.trip-details-page {
  padding: 16px;
  background: var(--color-background);
  min-height: 100vh;
}
.btn-back {
  background: transparent;
  border: 1px solid var(--color-primary);
  color: var(--color-primary);
  border-radius: 8px;
  font-size: 15px;
  padding: 8px 16px;
  cursor: pointer;
  margin-bottom: 12px;
  transition: background 0.2s;
}
.title {
  font-size: 20px;
  font-weight: bold;
  color: var(--color-text-primary);
  margin-bottom: 20px;
  text-align: center;
}
.details-block {
  background: var(--color-surface);
  border-radius: 12px;
  padding: 18px;
  margin-bottom: 18px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.06);
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.detail-row {
  font-size: 15px;
  color: var(--color-text-secondary);
  display: flex;
  justify-content: space-between;
  margin-bottom: 4px;
}
.btn {
  background: var(--color-primary);
  color: white;
  padding: 14px;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  width: 100%;
  cursor: pointer;
  margin-top: 8px;
  transition: background-color 0.2s;
}
.btn:hover {
  background-color: #0069d9;
}
.loading {
  text-align: center;
  color: var(--color-text-secondary);
  font-size: 16px;
  margin-top: 40px;
}
</style>
