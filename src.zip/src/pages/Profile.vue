<template>
  <div class="profile-page">
    <div class="profile-card">
      <img
        class="avatar"
        :src="auth.user.photo_url || '/avatar-placeholder.png'"
        alt="Фото пользователя"
      />
      <h2 class="name">
        {{ auth.user.first_name }}
        <span v-if="auth.user.last_name"> {{ auth.user.last_name }}</span>
      </h2>
      <p class="phone">Телефон: {{ auth.user.phone || "—" }}</p>
      <p class="description" v-if="auth.user.description">Описание: {{ auth.user.description }}</p>
      <div class="buttons">
        <router-link to="/edit-profile" class="btn">Редактировать профиль</router-link>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useAuthStore } from '@/store/auth';
const auth = useAuthStore();
</script>

<style scoped>
.profile-page { padding: 16px; min-height: 100vh; }
.profile-card { background: var(--color-surface); border-radius: 12px; padding: 16px; text-align: center; }
.avatar { width: 100px; height: 100px; border-radius: 50%; margin-bottom: 12px; object-fit: cover; }
.name { font-size: 20px; font-weight: bold; margin-bottom: 4px; }
.phone, .description { font-size: 14px; color: var(--color-text-secondary); margin-bottom: 6px; }
.buttons { margin-top: 16px; }
.btn { background: var(--color-primary); color: white; padding: 12px; border: none; border-radius: 8px; font-size: 15px; cursor: pointer; }
.btn:hover { background-color: #0069d9; }
</style>
