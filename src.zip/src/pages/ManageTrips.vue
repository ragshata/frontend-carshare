<template>
  <div class="manage-trips-page">
    <!-- 🔙 Кнопка Назад -->
      <div class="back-button-wrapper">
        <button class="back-button" @click="router.push('/main')">← Назад</button>
      </div>
    <h2 class="title">Мои поездки</h2>

    <div class="tabs">
      <button
        v-for="tab in tabs"
        :key="tab"
        :class="['tab', { active: currentTab === tab && tab !== '← Назад' }]"
        @click="handleTabClick(tab)"
      >
        {{ tab }}
      </button>
    </div>

    <div class="trip-list" v-if="currentTab !== '← Назад'">
      <div
        v-for="trip in filteredTrips"
        :key="trip.id"
        class="trip-card"
      >
        <div class="row between bold">
          {{ trip.from }} — {{ trip.to }}
          <span>{{ trip.price }}₽</span>
        </div>
        <div class="row">
          🗓 {{ trip.date }} &nbsp;&nbsp; ⏰ {{ trip.time }}
        </div>
        <div class="row">
          👤 {{ trip.driver }} &nbsp; ⭐ {{ trip.rating }} &nbsp; 👥 {{ trip.seats }} мест
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();

const tabs = ['Активные', 'История', 'Мои предложения', 'Черновики'];
const currentTab = ref(tabs[0]);

const handleTabClick = (tab: string) => {
  if (tab === '← Назад') {
    router.push('/main');
    return;
  }
  currentTab.value = tab;
};

const allTrips = ref([
  {
    id: 1,
    from: 'Душанбе',
    to: 'Худжанд',
    date: '2024-05-17',
    time: '08:00',
    price: 300,
    driver: 'Ахмад',
    rating: 4.9,
    seats: 3,
    status: 'Активные',
    type: 'водитель',
  },
  {
    id: 2,
    from: 'Худжанд',
    to: 'Душанбе',
    date: '2024-05-15',
    time: '18:00',
    price: 300,
    driver: 'Ахмад',
    rating: 4.9,
    seats: 2,
    status: 'История',
    type: 'пассажир',
  },
  {
    id: 3,
    from: 'Турсунзаде',
    to: 'Душанбе',
    date: '2024-05-18',
    time: '10:00',
    price: 250,
    driver: 'Ахмад',
    rating: 4.7,
    seats: 4,
    status: 'Черновики',
    type: 'водитель',
  },
]);

const filteredTrips = computed(() =>
  allTrips.value.filter((trip) => trip.status === currentTab.value)
);
</script>

<style scoped>
.manage-trips-page {
  padding: 16px;
  background: var(--color-background);
  min-height: 100vh;
}

.title {
  font-size: 20px;
  font-weight: bold;
  margin-bottom: 16px;
  color: var(--color-text-primary);
  text-align: center;
}

.back-button {
  background: transparent;
  border: 1px solid var(--color-primary);
  color: var(--color-primary);
  border-radius: 6px;
  padding: 6px 12px;
  font-size: 14px;
  cursor: pointer;
  transition: background 0.2s ease;
}
.tabs {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 20px;
}

.tab {
  padding: 10px 16px;
  border: 1px solid var(--color-primary);
  border-radius: 8px;
  background: transparent;
  color: var(--color-primary);
  cursor: pointer;
  font-size: 14px;
  transition: all 0.2s ease;
}

.tab.active {
  background: var(--color-primary);
  color: white;
}

.trip-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.trip-card {
  background: var(--color-surface);
  border-radius: 12px;
  padding: 16px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.row {
  font-size: 14px;
  color: var(--color-text-secondary);
  display: flex;
  flex-wrap: wrap;
}

.row.between {
  justify-content: space-between;
}

.bold {
  font-weight: bold;
  font-size: 16px;
  color: var(--color-text-primary);
}
</style>
