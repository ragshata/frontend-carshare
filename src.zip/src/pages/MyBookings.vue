<template>
  <div class="bookings-page">
    <div class="back-button-wrapper">
        <button class="back-button" @click="router.push('/main')">← Назад</button>
    </div>
    <div class="top-row">
      <h2 class="title">Мои бронирования</h2>
    </div>
    

    <div v-if="bookings.length === 0" class="empty-text">
      нет активных бронирований
    </div>

    <div v-else class="bookings-list">
      <div
        class="booking-card"
        v-for="booking in bookings"
        :key="booking.id"
      >
        <div class="row bold">
          {{ booking.from }} — {{ booking.to }}
        </div>
        <div class="row">
          🗓 {{ booking.date }} &nbsp;&nbsp; ⏰ {{ booking.time }}
        </div>
        <div class="row">
          💸 {{ booking.price }}₽ &nbsp; 👥 {{ booking.seats }} мест
        </div>
        <div class="row">
          👤 Водитель: {{ booking.driver }}
        </div>
        <button class="btn-cancel" @click="cancelBooking(booking.id)">
          Отменить бронь
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { useRouter } from 'vue-router';

// Интерфейс для бронирования
interface Booking {
  id: number;
  from: string;
  to: string;
  date: string;
  time: string;
  price: number;
  seats: number;
  driver: string;
}

const router = useRouter();
const bookings = ref<Booking[]>([
  // пример для теста:
  // {
  //   id: 1,
  //   from: "Душанбе",
  //   to: "Худжанд",
  //   date: "2024-06-01",
  //   time: "08:00",
  //   price: 300,
  //   seats: 2,
  //   driver: "Ахмад",
  // }
]);

function goBack() {
  router.push('/main');
}

function cancelBooking(id: number) {
  // Здесь должна быть отправка запроса на API для отмены
  bookings.value = bookings.value.filter(b => b.id !== id);
}
</script>

<style scoped>
.bookings-page {
  padding: 16px;
  background: var(--color-background);
  min-height: 100vh;
}
.top-row {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 16px;
}
.btn-back {
  background: transparent;
  border: 1px solid var(--color-primary);
  color: var(--color-primary);
  border-radius: 8px;
  font-size: 15px;
  padding: 8px 16px;
  cursor: pointer;
  transition: background 0.2s;
}
.title {
  font-size: 20px;
  font-weight: bold;
  color: var(--color-text-primary);
  flex: 1;
  text-align: center;
  margin: 0;
}
.empty-text {
  color: var(--color-text-secondary);
  font-size: 16px;
  text-align: center;
  margin-top: 32px;
}
.bookings-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.booking-card {
  background: var(--color-surface);
  border-radius: 12px;
  padding: 16px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.08);
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.row {
  font-size: 14px;
  color: var(--color-text-secondary);
}
.bold {
  font-weight: bold;
  font-size: 16px;
  color: var(--color-text-primary);
}
.btn-cancel {
  margin-top: 8px;
  background: #e53935;
  color: white;
  border: none;
  border-radius: 8px;
  padding: 10px;
  font-size: 15px;
  cursor: pointer;
  transition: background 0.2s;
}
.btn-cancel:hover {
  background: #c62828;
}
.back-button {
  background: transparent;
  border: 1px solid var(--color-primary);
  color: var(--color-primary);
  border-radius: 6px;
  padding: 6px 12px;
  font-size: 14px;
  cursor: pointer;
  transition: background 0.2s ease;
}
</style>
