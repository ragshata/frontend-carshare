<template>
    <div class="rate-driver-page">
      <h2 class="title">Оценка водителя</h2>
  
      <div class="trip-info">
        <p><strong>Поездка:</strong> {{ trip.from }} — {{ trip.to }}</p>
        <p><strong>Дата:</strong> {{ trip.date }} &nbsp;&nbsp; <strong>Время:</strong> {{ trip.time }}</p>
      </div>
  
      <div class="rating-section">
        <p class="subtitle">Ваша оценка:</p>
        <div class="stars">
          <span
            v-for="n in 5"
            :key="n"
            class="star"
            :class="{ active: n <= rating }"
            @click="rating = n"
          >★</span>
        </div>
      </div>
  
      <div class="review-section">
        <p class="subtitle">Отзыв:</p>
        <textarea v-model="review" placeholder="Напишите пару слов о поездке..." rows="4" />
      </div>
  
      <button class="btn" @click="submit">Отправить оценку</button>
    </div>
  </template>
  
  <script setup lang="ts">
  import { ref } from 'vue';
  import { useRouter } from 'vue-router';
  
  const router = useRouter();
  
  // В будущем — получать по ID
  const trip = {
    from: 'Душанбе',
    to: 'Худжанд',
    date: '2024-05-17',
    time: '08:00',
  };
  
  const rating = ref(0);
  const review = ref('');
  
  function submit() {
    if (rating.value === 0) {
      alert('Пожалуйста, выберите оценку ⭐');
      return;
    }
    console.log('Оценка отправлена:', rating.value, review.value);
    alert('Спасибо за отзыв!');
    router.push('/manage-trips'); // или куда нужно
  }
  </script>
  
  <style scoped>
  .rate-driver-page {
    padding: 16px;
    background: var(--color-background);
    min-height: 100vh;
  }
  
  .title {
    font-size: 20px;
    font-weight: bold;
    text-align: center;
    color: var(--color-text-primary);
    margin-bottom: 20px;
  }
  
  .trip-info p {
    margin-bottom: 6px;
    font-size: 14px;
    color: var(--color-text-secondary);
  }
  
  .subtitle {
    font-weight: 500;
    margin: 12px 0 4px;
    color: var(--color-text-primary);
  }
  
  .stars {
    display: flex;
    gap: 6px;
    font-size: 28px;
    user-select: none;
    margin-bottom: 12px;
  }
  
  .star {
    cursor: pointer;
    color: #ccc;
    transition: 0.2s;
  }
  
  .star.active {
    color: #f5b400;
  }
  
  textarea {
    width: 100%;
    padding: 12px;
    font-size: 15px;
    border: 1px solid var(--color-border);
    border-radius: 8px;
    background: var(--color-surface);
    color: var(--color-text-primary);
    outline: none;
    resize: none;
  }
  
  .btn {
    margin-top: 16px;
    background: var(--color-primary);
    color: white;
    border: none;
    padding: 12px;
    border-radius: 8px;
    font-size: 15px;
    width: 100%;
    cursor: pointer;
    transition: background-color 0.2s ease;
  }
  
  .btn:hover {
    background-color: #0069d9;
  }
  </style>
  