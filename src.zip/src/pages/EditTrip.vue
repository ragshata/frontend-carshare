<template>
  <div class="edit-trip-page">
    <h2 class="title">Создание поездки</h2>

    <form class="form" @submit.prevent="publishTrip">
      <div class="input-wrapper" v-for="field in fields" :key="field.key">
        <component
          :is="field.type === 'textarea' ? 'textarea' : 'input'"
          :type="field.inputType || 'text'"
          v-model="form[field.key]"
          :id="field.key"
          :rows="field.rows || null"
          required
          :placeholder="field.inputType === 'date' || field.inputType === 'time' ? ' ' : ''"
          @focus="active = field.key"
          @blur="onBlur(field.key)"
          :autofocus="field.key === 'from'"
          :class="[
            { error: errors[field.key] },
            (field.inputType === 'date' || field.inputType === 'time') ? 'clean-date' : ''
          ]"
        />
        <label :for="field.key" :class="{ lifted: isLifted(field.key) }">
          {{ field.label }}
        </label>
        <p class="error-text" v-if="errors[field.key]">Поле обязательно</p>
      </div>

      <div class="buttons">
        <button type="button" class="btn btn-outline" @click="saveDraft">
          Сохранить как черновик
        </button>
        <button type="submit" class="btn">
          Опубликовать поездку
        </button>
        <button type="button" class="btn btn-danger" @click="deleteTrip">
          Удалить поездку
        </button>
        <button type="button" class="btn btn-outline" @click="cancel">
          Отмена
        </button>
      </div>
    </form>

    <Toast ref="toastRef" />
  </div>
</template>

<script setup lang="ts">
import { reactive, ref, onMounted, onUnmounted } from 'vue';
import { useRouter } from 'vue-router';
import Toast from '@/components/Toast.vue';
import { createTrip } from '@/api/trips';

const router = useRouter();
const active = ref<string>('');
const errors = reactive<Record<string, boolean>>({});
const toastRef = ref<InstanceType<typeof Toast> | null>(null);

// BackButton для Telegram Mini Apps
onMounted(() => {
  window.Telegram?.WebApp?.BackButton?.show?.();
  window.Telegram?.WebApp?.BackButton?.onClick?.(() => {
    if (window.history.length > 1) {
      window.history.back();
    } else {
      window.Telegram?.WebApp?.close?.();
    }
  });
});
onUnmounted(() => {
  window.Telegram?.WebApp?.BackButton?.hide?.();
  window.Telegram?.WebApp?.BackButton?.offClick?.();
});

// Определяем интерфейс с индексной сигнатурой
interface TripForm {
  from: string;
  to: string;
  date: string;
  time: string;
  seats: string;
  price: string;
  description: string;
  [key: string]: string;
}

// Инициализируем форму
const form = reactive<TripForm>({
  from: '',
  to: '',
  date: '',
  time: '',
  seats: '',
  price: '',
  description: '',
});

// Описание полей
const fields = [
  { key: 'from', label: 'Откуда' },
  { key: 'to', label: 'Куда' },
  { key: 'date', label: 'Дата выезда', inputType: 'date' },
  { key: 'time', label: 'Время выезда', inputType: 'time' },
  { key: 'seats', label: 'Количество мест', inputType: 'number' },
  { key: 'price', label: 'Стоимость', inputType: 'number' },
  { key: 'description', label: 'Дополнительная информация', type: 'textarea', rows: 3 },
];

function isLifted(key: string) {
  return active.value === key || !!form[key];
}

function onBlur(key: string) {
  if (!form[key]) active.value = '';
}

function validate() {
  let valid = true;
  for (const field of fields) {
    if (!form[field.key]) {
      errors[field.key] = true;
      valid = false;
    } else {
      errors[field.key] = false;
    }
  }
  return valid;
}

async function publishTrip() {
  if (!validate()) return;

  try {
    await createTrip({
      from: form.from,
      to: form.to,
      date: form.date,
      time: form.time,
      seats: Number(form.seats),
      price: Number(form.price),
      description: form.description,
      is_draft: false,
    });

    toastRef.value?.show('🚗 Поездка опубликована');
    setTimeout(() => router.push('/my-trips'), 1500);
  } catch (error) {
    toastRef.value?.show('❌ Ошибка при публикации поездки');
    console.error(error);
  }
}

async function saveDraft() {
  if (!validate()) return;

  try {
    await createTrip({
      from: form.from,
      to: form.to,
      date: form.date,
      time: form.time,
      seats: Number(form.seats),
      price: Number(form.price),
      description: form.description,
      is_draft: true,
    });

    toastRef.value?.show('💾 Черновик сохранён');
    setTimeout(() => router.push('/my-trips'), 1500);
  } catch (error) {
    toastRef.value?.show('❌ Ошибка при сохранении черновика');
    console.error(error);
  }
}

function deleteTrip() {
  toastRef.value?.show('❌ Поездка удалена');
  setTimeout(() => router.push('/my-trips'), 1500);
}

function cancel() {
  router.push('/my-trips');
}
</script>

<style scoped>
/* ...оставь твои стили без изменений */
</style>
