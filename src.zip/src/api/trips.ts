import axios from "axios";

const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:8000";

// Тип поездки (Trip) — если хочешь строгость, вынеси в types.ts
export interface Trip {
  id: number;
  from_city: string;
  to_city: string;
  date: string;
  time: string;
  price: number;
  seats: number;
  driver_id: number;
  status: string;
  // другие поля по модели
}

// Поиск поездок с фильтрами
export async function searchTrips(params: {
  from_city?: string;
  to_city?: string;
  date?: string;
  date_from?: string;
  date_to?: string;
  status?: string;
  maxPrice?: string | number;
}): Promise<Trip[]> {
  const res = await axios.get(`${API_BASE}/trips`, { params });
  return res.data;
}

// Получить подробную инфу о поездке
export async function getTrip(id: number): Promise<Trip> {
  const res = await axios.get(`${API_BASE}/trips/${id}`);
  return res.data;
}

// Создать новую поездку (для OfferTrip)
export async function createTrip(payload: Record<string, any>): Promise<Trip> {
  const res = await axios.post(`${API_BASE}/trips/create/`, payload);
  return res.data;
}
export async function getTripById(id: number) {
  const res = await axios.get(`${API_BASE}/trips/${id}`);
  return res.data;
}