import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:8000';

// Тип бронирования (Booking)
export interface Booking {
  id: number;
  trip_id: number;
  user_id: number;
  // можно добавить trip?: Trip если хочешь досконально
}

// Получить мои бронирования (user_id можно брать из store)
export async function getBookings(user_id: number): Promise<Booking[]> {
  const res = await axios.get(`${API_BASE}/bookings`, { params: { user_id } });
  return res.data;
}

// Забронировать поездку
export async function bookTrip(trip_id: number, user_id: number): Promise<Booking> {
  const response = await axios.post(`${API_BASE}/bookings`, {
    trip_id,
    user_id
  });
  return response.data;
}

// Отменить бронирование
export async function deleteBooking(id: number) {
  return axios.delete(`${API_BASE}/bookings/${id}`);
}
