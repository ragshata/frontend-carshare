declare module '@unocss/vite';
